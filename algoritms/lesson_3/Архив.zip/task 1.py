"""
1. В диапазоне натуральных чисел от 2 до 99 определить, сколько из них кратны каждому из чисел в диапазоне от 2 до 9.
Примечание: 8 разных ответов.
"""

spam = {i: 0 for i in range(2, 10)}

for key in spam.keys():
    for j in range(2, 100):
        if j % key == 0:
            spam[key] += 1

for key, value in spam.items():
    print(f'Числу {key} кратны {value} чисел')