"""
3. В массиве случайных целых чисел поменять местами минимальный и максимальный элементы.
"""

import random

spam = [random.randint(0, 100) for _ in range(0, 20)]

print(spam)

min_pos = 0
max_pos = 0
min_value = spam[0]
max_value = spam[0]
for i, value in enumerate(spam):

    if value < min_value:
        min_pos = i
        min_value = value

    if value >= max_value:
        max_pos = i
        max_value = value

spam[min_pos], spam[max_pos] = spam[max_pos], spam[min_pos]

print(f'Минимальный элемент имеет значение {min_value} на позиции {min_pos}\n'
      f'Максимальный элемент имеет значение {max_value} на позиции {max_pos}')
print(spam)
