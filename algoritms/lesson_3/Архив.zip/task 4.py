"""
4. Определить, какое число в массиве встречается чаще всего.
"""
import random

spam = [random.randint(0, 6) for _ in range(0, 100)]

print(spam)

spam_unique = list(set(spam))

max_value = spam_unique[0]
max_count = 0
for key in spam_unique:
    if max_count < spam.count(key):
        max_value = key
        max_count = spam.count(key)

print(f'Максимальное число {max_value} встречается {max_count}')
