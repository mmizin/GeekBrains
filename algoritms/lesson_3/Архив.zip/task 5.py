"""
5. В массиве найти максимальный отрицательный элемент. Вывести на экран его значение и позицию в массиве.

Примечание к задаче: пожалуйста не путайте «минимальный» и «максимальный отрицательный».
Это два абсолютно разных значения.
"""
import random

spam = [random.randint(-20, 100) for _ in range(0, 20)]

print(spam)

max_min_element = 0

for i in spam:
    if max_min_element < i < 0 or max_min_element == 0 and i < 0:
        max_min_element = i

print(max_min_element)
print(f'Максимальный отрицательный элемент равен {max_min_element}' if max_min_element != 0
      else f'Максимального отрицательного элемента не существует в массивае')

